import { getConnection, closeConnection, mockOpenConnection } from 'trophy-rds-connection/index.mjs';
import { retrieveExercise } from 'trophy-database-operations/ExerciseOperations.mjs';
import { translateExerciseSQLRowToJSON } from 'trophy-exercise-data-processing/SQLJSONTranslator.mjs';
import { ERROR } from 'trophy-common-utils/Errors.mjs';
import { compareUserId } from 'trophy-common-utils/IdComparators.mjs';
import { prepareExerciseResponse } from 'trophy-common-utils/PrepareAPIResponse.mjs';

/**
 * Lambda function handler for retrieving an Exercise entry.
 * 
 * @param {Object} event - The event object containing information about the HTTP request.
 * @param {Object} context - The context object providing runtime information.
 * @returns {Promise<Object>} A Promise that resolves to the response object containing the retrieved Exercise entry or an error message.
 */
export const handler = async function (event, context) {
    try {
        // Parse the JSON body from the event
        const requestBody = JSON.parse(event.body); // For actual usage
        // const requestBody = event.body; //For lambda test events

        // Throw error if userId is undefined or null
        const userId = event.pathParameters.userId;
        if (userId === undefined || userId === null) {
            console.log("User ID data value:", userId);
            console.log("User ID data type:", typeof userId);
            throw new Error(`${ERROR.ERROR_INVALID_LAMBDA_PARAMETER_UNDEFINED_NULL}`);
        }
        
        // Throw error if exerciseId is undefined or null
        const exerciseId = event.pathParameters.exerciseId;
        if (exerciseId === undefined || exerciseId === null) {
            console.log("Exercise ID data value:", exerciseId);
            console.log("Exercise ID data type:", typeof exerciseId);
            throw new Error(`${ERROR.ERROR_INVALID_LAMBDA_PARAMETER_UNDEFINED_NULL}`);
        }

        // Confirmed values needed from API Gateway are valid and usable!

        // Get/Open DB Connection
        const connection = await getConnection();
        // const connection =  await mockOpenConnection();

        // Call Retrieve Exercise function
        const exerciseRow = await retrieveExercise(exerciseId, connection);

        // Throw error, if there were no entries found
        if (exerciseRow === null) {
            throw new Error(`${ERROR.ERROR_RETRIEVE_EXERCISE_FAILED_NOT_FOUND} using:
                exerciseId: ${exerciseId}
                userId: ${userId}`);
        }

        // Translate the Exercise Row into a JSON format
        const exercise = translateExerciseSQLRowToJSON(exerciseRow);

        // Throw error if userId !== exercise.userId
        if (!compareUserId(userId, exercise.user_id)) {
            console.log(`User with userId ${userId} does not have permission to view this Exercise. Likely due to mismatching user id's`);
            throw new Error(`${ERROR.ERROR_RETRIEVE_EXERCISE_FAILED_PERMISSION_DENIED}`);
        }

        // Prepare the JSON response for API Gateway
        const response = await prepareExerciseResponse(exercise, connection);

        // Prepare the Exercise API response

        // Return a 200 response and retrieved Exercise entry
        return {
            statusCode: 200,
            body: JSON.stringify({ 
                exercise: response,
                message: 'Function executed successfully' 
            })
        };

    } catch(error) {
        // Log function details (e.g. userId, exerciseId)
        console.log("Failed with userId", event.pathParameters.userId);
        console.log("Failed with exerciseId", event.pathParameters.exerciseId);

        // Log error details
        console.log(error.message);

        // Return body with error status code, error message, and any other details needed
        return {
            statusCode: 500,
            body: JSON.stringify({ 
                exerciseId: event.pathParameters.exerciseId,
                userId: event.pathParameters.userId,
                message: 'Internal server error' 
            })
        };
    } finally {
        // Close the DB connection
        await closeConnection();
    }
}